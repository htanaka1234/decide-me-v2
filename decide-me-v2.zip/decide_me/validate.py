from __future__ import annotations

from collections import defaultdict
from typing import Any

from decide_me.constants import ACCEPTED_VIA_VALUES, DOMAIN_VALUES, EVIDENCE_SOURCES
from decide_me.events import EVENT_TYPES, make_event_id, validate_event
from decide_me.taxonomy import taxonomy_by_id


OPEN_DECISION_STATUSES = {"unresolved", "proposed", "rejected", "blocked"}
FINAL_INVALIDATING_STATUSES = {"accepted", "resolved-by-evidence"}
ALL_DECISION_STATUSES = OPEN_DECISION_STATUSES | {
    "accepted",
    "deferred",
    "resolved-by-evidence",
    "invalidated",
}
PRIORITIES = {"P0", "P1", "P2"}
FRONTIERS = {"now", "later", "discovered-later", "deferred"}
KINDS = {"choice", "constraint", "risk", "dependency"}
RESOLVABLE_BY = {"human", "codebase", "docs", "tests", "external"}
REVERSIBILITY = {"reversible", "hard-to-reverse", "irreversible", "unknown"}
SESSION_LIFECYCLE_STATUSES = {"active", "closed"}
TAXONOMY_AXES = {"domain", "abstraction_level", "tag"}
TAXONOMY_STATUSES = {"active", "replaced"}
SESSION_MUTATION_EVENT_TYPES = {
    "session_resumed",
    "decision_discovered",
    "decision_enriched",
    "question_asked",
    "proposal_issued",
    "proposal_accepted",
    "proposal_rejected",
    "decision_deferred",
    "decision_resolved_by_evidence",
    "classification_updated",
    "close_summary_generated",
}


class StateValidationError(ValueError):
    """Raised when a projection is malformed."""


def _require_keys(payload: dict[str, Any], keys: tuple[str, ...], label: str) -> None:
    missing = [key for key in keys if key not in payload]
    if missing:
        raise StateValidationError(f"{label} is missing required keys: {', '.join(missing)}")


def validate_project_state(project_state: dict[str, Any]) -> None:
    _require_keys(
        project_state,
        ("schema_version", "project", "state", "protocol", "counts", "default_bundles", "decisions"),
        "project_state",
    )
    _require_keys(
        project_state["project"],
        ("name", "objective", "current_milestone", "stop_rule"),
        "project_state.project",
    )
    for key in ("name", "objective", "current_milestone", "stop_rule"):
        _require_non_empty_string(project_state["project"].get(key), f"project_state.project.{key}")
    _require_keys(
        project_state["state"],
        ("project_version", "updated_at", "last_event_id"),
        "project_state.state",
    )
    if not isinstance(project_state["decisions"], list):
        raise StateValidationError("project_state.decisions must be a list")

    decision_ids: set[str] = set()
    for decision in project_state["decisions"]:
        _require_keys(
            decision,
            (
                "id",
                "title",
                "kind",
                "domain",
                "priority",
                "frontier",
                "status",
                "resolvable_by",
                "reversibility",
                "depends_on",
                "blocked_by",
                "question",
                "context",
                "options",
                "recommendation",
                "accepted_answer",
                "resolved_by_evidence",
                "evidence_refs",
                "revisit_triggers",
                "notes",
                "bundle_id",
                "invalidated_by",
            ),
            f"decision[{decision.get('id', '?')}]",
        )
        if decision["status"] not in ALL_DECISION_STATUSES:
            raise StateValidationError(f"unsupported decision status: {decision['status']}")
        _require_enum(decision["priority"], PRIORITIES, f"decision {decision['id']}.priority")
        _require_enum(decision["frontier"], FRONTIERS, f"decision {decision['id']}.frontier")
        _require_enum(decision["kind"], KINDS, f"decision {decision['id']}.kind")
        _require_enum(decision["domain"], DOMAIN_VALUES, f"decision {decision['id']}.domain")
        _require_enum(
            decision["resolvable_by"], RESOLVABLE_BY, f"decision {decision['id']}.resolvable_by"
        )
        _require_enum(
            decision["reversibility"], REVERSIBILITY, f"decision {decision['id']}.reversibility"
        )
        _require_list(decision["depends_on"], f"decision {decision['id']}.depends_on")
        _require_list(decision["blocked_by"], f"decision {decision['id']}.blocked_by")
        _require_list(decision["options"], f"decision {decision['id']}.options")
        _require_list(decision["evidence_refs"], f"decision {decision['id']}.evidence_refs")
        _require_list(decision["revisit_triggers"], f"decision {decision['id']}.revisit_triggers")
        _require_list(decision["notes"], f"decision {decision['id']}.notes")
        _require_dict(decision["recommendation"], f"decision {decision['id']}.recommendation")
        _require_dict(decision["accepted_answer"], f"decision {decision['id']}.accepted_answer")
        resolved_by_evidence = _require_dict(
            decision["resolved_by_evidence"], f"decision {decision['id']}.resolved_by_evidence"
        )
        _require_list(
            resolved_by_evidence.get("evidence_refs"),
            f"decision {decision['id']}.resolved_by_evidence.evidence_refs",
        )
        _validate_decision_status_payload(decision)
        if decision["id"] in decision_ids:
            raise StateValidationError(f"duplicate decision id: {decision['id']}")
        decision_ids.add(decision["id"])
    expected_counts = _recomputed_counts(project_state["decisions"])
    if project_state["counts"] != expected_counts:
        raise StateValidationError("project_state.counts does not match decision state")


def _validate_decision_status_payload(decision: dict[str, Any]) -> None:
    decision_id = decision["id"]
    status = decision["status"]
    accepted_summary = decision.get("accepted_answer", {}).get("summary")
    evidence_summary = decision.get("resolved_by_evidence", {}).get("summary")
    if status == "accepted":
        _require_non_empty_string(accepted_summary, f"decision {decision_id}.accepted_answer.summary")
        _require_enum(
            decision.get("accepted_answer", {}).get("accepted_via"),
            ACCEPTED_VIA_VALUES - {"evidence"},
            f"decision {decision_id}.accepted_answer.accepted_via",
        )
    elif status == "resolved-by-evidence":
        resolved = decision.get("resolved_by_evidence", {})
        _require_non_empty_string(resolved.get("summary"), f"decision {decision_id}.resolved_by_evidence.summary")
        _require_non_empty_string(resolved.get("source"), f"decision {decision_id}.resolved_by_evidence.source")
        _require_enum(
            resolved.get("source"),
            EVIDENCE_SOURCES,
            f"decision {decision_id}.resolved_by_evidence.source",
        )
        if decision.get("accepted_answer", {}).get("accepted_via") != "evidence":
            raise StateValidationError(
                f"decision {decision_id}.accepted_answer.accepted_via must be evidence"
            )
    elif status in {"unresolved", "proposed", "rejected", "deferred", "blocked"}:
        if accepted_summary:
            raise StateValidationError(
                f"decision {decision_id} with status {status} must not have accepted_answer.summary"
            )
        if evidence_summary:
            raise StateValidationError(
                f"decision {decision_id} with status {status} must not have resolved_by_evidence.summary"
            )


def validate_session_state(session_state: dict[str, Any]) -> None:
    _require_keys(
        session_state,
        ("schema_version", "session", "summary", "classification", "close_summary", "working_state"),
        "session_state",
    )
    _require_keys(
        session_state["session"],
        ("id", "started_at", "last_seen_at", "bound_context_hint", "decision_ids", "lifecycle"),
        "session_state.session",
    )
    _require_list(session_state["session"]["decision_ids"], "session_state.session.decision_ids")
    lifecycle = _require_dict(session_state["session"]["lifecycle"], "session_state.session.lifecycle")
    _require_keys(lifecycle, ("status", "closed_at"), "session_state.session.lifecycle")
    _require_enum(lifecycle["status"], SESSION_LIFECYCLE_STATUSES, "session_state.session.lifecycle.status")
    if lifecycle["status"] == "closed":
        _require_non_empty_string(lifecycle.get("closed_at"), "session_state.session.lifecycle.closed_at")
    elif lifecycle.get("closed_at") is not None:
        raise StateValidationError("active session lifecycle.closed_at must be null")
    _require_keys(
        session_state["summary"],
        ("latest_summary", "current_question_preview", "active_decision_id"),
        "session_state.summary",
    )
    _require_keys(
        session_state["classification"],
        (
            "domain",
            "abstraction_level",
            "assigned_tags",
            "compatibility_tags",
            "search_terms",
            "source_refs",
            "updated_at",
        ),
        "session_state.classification",
    )
    _require_keys(
        session_state["close_summary"],
        (
            "work_item_title",
            "work_item_statement",
            "goal",
            "readiness",
            "accepted_decisions",
            "deferred_decisions",
            "unresolved_blockers",
            "unresolved_risks",
            "candidate_workstreams",
            "candidate_action_slices",
            "evidence_refs",
            "generated_at",
        ),
        "session_state.close_summary",
    )
    _require_keys(
        session_state["working_state"],
        ("current_question_id", "current_question", "active_proposal", "last_seen_project_version"),
        "session_state.working_state",
    )
    for key in ("assigned_tags", "compatibility_tags", "search_terms", "source_refs"):
        _require_list(session_state["classification"][key], f"session_state.classification.{key}")
    for key in (
        "accepted_decisions",
        "deferred_decisions",
        "unresolved_blockers",
        "unresolved_risks",
        "candidate_workstreams",
        "candidate_action_slices",
        "evidence_refs",
    ):
        _require_list(session_state["close_summary"][key], f"session_state.close_summary.{key}")


def validate_taxonomy_state(taxonomy_state: dict[str, Any]) -> None:
    _require_keys(taxonomy_state, ("schema_version", "state", "required_axes", "nodes"), "taxonomy_state")
    _require_keys(taxonomy_state["state"], ("updated_at", "last_event_id"), "taxonomy_state.state")
    node_ids = taxonomy_by_id(taxonomy_state)
    if len(node_ids) != len(taxonomy_state["nodes"]):
        raise StateValidationError("taxonomy_state.nodes contains duplicate ids")
    for node in taxonomy_state["nodes"]:
        _require_keys(
            node,
            ("id", "axis", "label", "aliases", "parent_id", "replaced_by", "status", "created_at", "updated_at"),
            f"taxonomy node {node.get('id', '?')}",
        )
        _require_enum(node["axis"], TAXONOMY_AXES, f"taxonomy node {node['id']}.axis")
        _require_enum(node["status"], TAXONOMY_STATUSES, f"taxonomy node {node['id']}.status")
        _require_list(node["aliases"], f"taxonomy node {node['id']}.aliases")
        _require_list(node["replaced_by"], f"taxonomy node {node['id']}.replaced_by")


def validate_projection_bundle(bundle: dict[str, Any]) -> None:
    _require_keys(bundle, ("project_state", "taxonomy_state", "sessions"), "projection_bundle")
    validate_project_state(bundle["project_state"])
    validate_taxonomy_state(bundle["taxonomy_state"])
    if not isinstance(bundle["sessions"], dict):
        raise StateValidationError("projection_bundle.sessions must be a dictionary")
    decisions_by_id = _decision_index(bundle["project_state"])
    taxonomy_ids = set(taxonomy_by_id(bundle["taxonomy_state"]))
    active_proposal_targets: dict[str, list[str]] = {}
    for session_id, session in bundle["sessions"].items():
        validate_session_state(session)
        _validate_session_integrity(session_id, session, decisions_by_id, taxonomy_ids)
        proposal = session["working_state"]["active_proposal"]
        if proposal.get("is_active") and proposal.get("target_id"):
            active_proposal_targets.setdefault(proposal["target_id"], []).append(session_id)
    _validate_decision_references(decisions_by_id, active_proposal_targets)


def _decision_index(project_state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {decision["id"]: decision for decision in project_state["decisions"]}


def _visible_decision_ids(decisions_by_id: dict[str, dict[str, Any]]) -> set[str]:
    return {
        decision_id
        for decision_id, decision in decisions_by_id.items()
        if decision.get("status") != "invalidated"
    }


def _validate_decision_references(
    decisions_by_id: dict[str, dict[str, Any]], active_proposal_targets: dict[str, list[str]]
) -> None:
    for decision_id, decision in decisions_by_id.items():
        for key in ("depends_on", "blocked_by"):
            for referenced_id in decision.get(key, []):
                if referenced_id not in decisions_by_id:
                    raise StateValidationError(
                        f"decision {decision_id}.{key} references unknown decision {referenced_id}"
                    )

        invalidated_by = decision.get("invalidated_by")
        if decision["status"] == "invalidated":
            invalidated_by = _require_dict(invalidated_by, f"decision {decision_id}.invalidated_by")
            invalidating_id = invalidated_by.get("decision_id")
            if invalidating_id not in decisions_by_id:
                raise StateValidationError(f"decision {decision_id} has invalid invalidated_by reference")
            if not _has_final_invalidating_chain(invalidating_id, decisions_by_id, seen={decision_id}):
                raise StateValidationError(
                    f"decision {decision_id} is invalidated by non-final decision {invalidating_id}"
                )
        elif invalidated_by is not None:
            raise StateValidationError(f"non-invalidated decision {decision_id} must not carry invalidated_by")

        accepted_proposal_id = decision.get("accepted_answer", {}).get("proposal_id")
        recommended_proposal_id = decision.get("recommendation", {}).get("proposal_id")
        if accepted_proposal_id and accepted_proposal_id != recommended_proposal_id:
            raise StateValidationError(
                f"decision {decision_id} accepted_answer.proposal_id does not match recommendation.proposal_id"
            )
        if decision["status"] == "proposed":
            _require_non_empty_string(
                decision.get("recommendation", {}).get("proposal_id"),
                f"decision {decision_id}.recommendation.proposal_id",
            )
            owners = active_proposal_targets.get(decision_id, [])
            if len(owners) != 1:
                raise StateValidationError(
                    f"decision {decision_id} is proposed but has {len(owners)} active proposal targets"
                )


def _validate_session_integrity(
    session_key: str,
    session: dict[str, Any],
    decisions_by_id: dict[str, dict[str, Any]],
    taxonomy_ids: set[str],
) -> None:
    session_id = session["session"]["id"]
    if session_id != session_key:
        raise StateValidationError(f"session map key {session_key} does not match session id {session_id}")

    visible_ids = _visible_decision_ids(decisions_by_id)
    decision_ids = session["session"]["decision_ids"]
    if len(decision_ids) != len(set(decision_ids)):
        raise StateValidationError(f"session {session_id} contains duplicate decision_ids")
    for decision_id in decision_ids:
        if decision_id not in decisions_by_id:
            raise StateValidationError(f"session {session_id} references unknown decision {decision_id}")
        if decision_id not in visible_ids:
            raise StateValidationError(f"session {session_id} references invalidated decision {decision_id}")

    active_decision_id = session["summary"].get("active_decision_id")
    if active_decision_id and active_decision_id not in set(decision_ids):
        raise StateValidationError(f"session {session_id} active_decision_id is not bound to the session")
    if active_decision_id and active_decision_id not in visible_ids:
        raise StateValidationError(f"session {session_id} active_decision_id references invalidated decision")

    _validate_classification_refs(session_id, session, taxonomy_ids)
    _validate_active_proposal(session_id, session, decisions_by_id, visible_ids, set(decision_ids))
    _validate_close_summary(session_id, session, decisions_by_id, visible_ids, set(decision_ids))


def _validate_classification_refs(
    session_id: str, session: dict[str, Any], taxonomy_ids: set[str]
) -> None:
    classification = session["classification"]
    domain = classification.get("domain")
    if domain is not None:
        _require_enum(domain, DOMAIN_VALUES, f"session {session_id} classification.domain")
    for key in ("assigned_tags", "compatibility_tags"):
        for tag_ref in classification.get(key, []):
            if tag_ref not in taxonomy_ids:
                raise StateValidationError(f"session {session_id} {key} references unknown taxonomy node {tag_ref}")


def _validate_active_proposal(
    session_id: str,
    session: dict[str, Any],
    decisions_by_id: dict[str, dict[str, Any]],
    visible_ids: set[str],
    session_decision_ids: set[str],
) -> None:
    working_state = session["working_state"]
    active = working_state["active_proposal"]
    _require_keys(
        active,
        (
            "proposal_id",
            "origin_session_id",
            "target_type",
            "target_id",
            "recommendation_version",
            "based_on_project_version",
            "is_active",
            "activated_at",
            "inactive_reason",
            "question_id",
            "question",
            "recommendation",
            "why",
            "if_not",
        ),
        f"session {session_id} active_proposal",
    )

    lifecycle_status = session["session"]["lifecycle"]["status"]
    if lifecycle_status == "closed" and active.get("is_active"):
        raise StateValidationError(f"closed session {session_id} must not have an active proposal")
    if lifecycle_status == "closed" and (
        working_state.get("current_question_id") or working_state.get("current_question")
    ):
        raise StateValidationError(f"closed session {session_id} must not have current question state")
    if lifecycle_status == "closed":
        _require_non_empty_string(
            session["close_summary"].get("generated_at"),
            f"session {session_id}.close_summary.generated_at",
        )

    proposal_id = active.get("proposal_id")
    if not proposal_id:
        return

    if active.get("origin_session_id") != session_id:
        raise StateValidationError(f"session {session_id} active proposal has wrong origin_session_id")

    target_id = active.get("target_id")
    if not target_id:
        if active.get("is_active"):
            raise StateValidationError(f"session {session_id} active proposal is missing target_id")
        return
    if active.get("target_type") != "decision":
        raise StateValidationError(f"session {session_id} active proposal has unsupported target_type")
    if target_id not in decisions_by_id:
        raise StateValidationError(f"session {session_id} active proposal references unknown decision {target_id}")
    if target_id not in visible_ids:
        raise StateValidationError(f"session {session_id} active proposal references invalidated decision {target_id}")
    if target_id not in session_decision_ids:
        raise StateValidationError(f"session {session_id} active proposal target is not bound to the session")

    if active.get("is_active"):
        decision = decisions_by_id[target_id]
        if decision["status"] != "proposed":
            raise StateValidationError(
                f"session {session_id} active proposal target {target_id} is not proposed"
            )
        if session["summary"].get("active_decision_id") != target_id:
            raise StateValidationError(f"session {session_id} active proposal does not match active_decision_id")
        if decision.get("recommendation", {}).get("proposal_id") != proposal_id:
            raise StateValidationError(f"session {session_id} active proposal is not the decision recommendation")


def _validate_close_summary(
    session_id: str,
    session: dict[str, Any],
    decisions_by_id: dict[str, dict[str, Any]],
    visible_ids: set[str],
    session_decision_ids: set[str],
) -> None:
    close_summary = session["close_summary"]
    expected_readiness = _close_summary_readiness(close_summary)
    if close_summary.get("readiness") != expected_readiness:
        raise StateValidationError(
            f"session {session_id} close_summary.readiness must be {expected_readiness}"
        )
    visible_session_ids = session_decision_ids & visible_ids
    for key in (
        "accepted_decisions",
        "deferred_decisions",
        "unresolved_blockers",
        "unresolved_risks",
    ):
        for item in close_summary.get(key, []):
            decision_id = item.get("id")
            _require_visible_summary_decision(session_id, key, decision_id, visible_session_ids)

    action_decision_ids: set[str] = set()
    for action_slice in close_summary.get("candidate_action_slices", []):
        decision_id = action_slice.get("decision_id")
        _require_visible_summary_decision(
            session_id, "candidate_action_slices", decision_id, visible_session_ids
        )
        decision = decisions_by_id[decision_id]
        if decision["status"] not in {"accepted", "resolved-by-evidence"}:
            raise StateValidationError(
                f"session {session_id} candidate_action_slices references non-accepted decision {decision_id}"
            )
        action_decision_ids.add(decision_id)

    for workstream in close_summary.get("candidate_workstreams", []):
        for key in ("scope", "implementation_ready_scope"):
            for decision_id in workstream.get(key, []):
                _require_visible_summary_decision(
                    session_id,
                    f"candidate_workstreams.{key}",
                    decision_id,
                    visible_session_ids,
                )
        for decision_id in workstream.get("implementation_ready_scope", []):
            if decision_id not in action_decision_ids:
                raise StateValidationError(
                    f"session {session_id} workstream implementation_ready_scope is missing action slice {decision_id}"
                )


def _require_visible_summary_decision(
    session_id: str, section: str, decision_id: str | None, visible_session_ids: set[str]
) -> None:
    if not decision_id:
        raise StateValidationError(f"session {session_id} {section} item is missing a decision id")
    if decision_id not in visible_session_ids:
        raise StateValidationError(f"session {session_id} {section} references non-visible decision {decision_id}")


def _close_summary_readiness(close_summary: dict[str, Any]) -> str:
    if close_summary.get("unresolved_blockers"):
        return "blocked"
    if close_summary.get("unresolved_risks"):
        return "conditional"
    return "ready"


def validate_event_log(events: list[dict[str, Any]]) -> None:
    if not events:
        return
    first = events[0]
    if first.get("event_type") != "project_initialized":
        raise StateValidationError("event log must start with project_initialized")
    if first.get("session_id") != "SYSTEM":
        raise StateValidationError("project_initialized event must use SYSTEM session_id")

    previous_version = 0
    event_ids: set[str] = set()
    created_session_ids: set[str] = {"SYSTEM"}
    session_status: dict[str, str] = {"SYSTEM": "active"}
    session_decision_ids: dict[str, set[str]] = defaultdict(set)
    decision_status: dict[str, str] = {}
    has_close_summary: dict[str, bool] = {}
    discovered_decision_ids: set[str] = set()
    issued_proposals: dict[str, dict[str, str]] = {}
    active_proposal_by_session: dict[str, str | None] = {}
    disabled_proposals: set[str] = set()
    accepted_proposals: set[str] = set()
    rejected_proposals: set[str] = set()
    pending_rejected_proposal_id: str | None = None
    project_initialized_count = 0
    for sequence, event in enumerate(events, start=1):
        validate_event(event)
        if event["event_type"] not in EVENT_TYPES:
            raise StateValidationError(f"unsupported event type in log: {event['event_type']}")
        if event["event_id"] in event_ids:
            raise StateValidationError(f"duplicate event id: {event['event_id']}")
        event_ids.add(event["event_id"])
        expected_event_id = make_event_id(sequence, event["ts"])
        if event["event_id"] != expected_event_id:
            raise StateValidationError(
                f"event_id {event['event_id']} does not match sequence {sequence}"
            )
        if event["event_type"] == "project_initialized":
            if event["session_id"] != "SYSTEM":
                raise StateValidationError("project_initialized event must use SYSTEM session_id")
            project_initialized_count += 1
            if project_initialized_count > 1:
                raise StateValidationError("event log must contain exactly one project_initialized event")
            project = event["payload"]["project"]
            for key in ("name", "objective", "current_milestone", "stop_rule"):
                _require_non_empty_string(project.get(key), f"project_initialized.payload.project.{key}")
        elif event["event_type"] == "session_created":
            created_session_id = event["payload"]["session"]["id"]
            if event["session_id"] != created_session_id:
                raise StateValidationError("session_created event.session_id must match payload.session.id")
            if created_session_id in created_session_ids:
                raise StateValidationError(f"duplicate session_created id: {created_session_id}")
            created_session_ids.add(created_session_id)
            session_status[created_session_id] = "active"
            session_decision_ids[created_session_id] = set()
            has_close_summary[created_session_id] = False
            active_proposal_by_session[created_session_id] = None
        else:
            if event["session_id"] != "SYSTEM" and event["session_id"] not in created_session_ids:
                raise StateValidationError(f"event references unknown session: {event['session_id']}")
            if (
                event["event_type"] in SESSION_MUTATION_EVENT_TYPES
                and session_status.get(event["session_id"]) == "closed"
            ):
                raise StateValidationError(
                    f"{event['event_type']} mutates closed session {event['session_id']}"
                )
            if event["event_type"] == "session_closed":
                if session_status.get(event["session_id"]) == "closed":
                    raise StateValidationError(f"session {event['session_id']} is already closed")
                if not has_close_summary.get(event["session_id"]):
                    raise StateValidationError(
                        f"session_closed requires prior close_summary_generated for {event['session_id']}"
                    )
        if event["event_type"] == "decision_discovered":
            decision_id = event["payload"]["decision"]["id"]
            if decision_id in discovered_decision_ids:
                raise StateValidationError(f"duplicate decision_discovered id: {decision_id}")
            discovered_decision_ids.add(decision_id)
            session_decision_ids[event["session_id"]].add(decision_id)
            decision_status[decision_id] = event["payload"]["decision"].get("status") or "unresolved"
        else:
            for decision_id in _decision_refs_in_event(event):
                if decision_id not in discovered_decision_ids:
                    raise StateValidationError(
                        f"{event['event_type']} references undiscovered decision {decision_id}"
                    )
        _validate_event_log_session_decision_binding(event, session_decision_ids)
        _validate_event_log_proposal_lifecycle(
            event,
            issued_proposals,
            active_proposal_by_session,
            disabled_proposals,
            accepted_proposals,
            rejected_proposals,
        )
        accepts_immediate_rejected_proposal = (
            event["event_type"] == "proposal_accepted"
            and event["payload"]["proposal_id"] == pending_rejected_proposal_id
        )
        _validate_event_log_decision_transition(
            event,
            decision_status,
            accepts_immediate_rejected_proposal=accepts_immediate_rejected_proposal,
        )
        if event["event_type"] == "proposal_rejected":
            pending_rejected_proposal_id = event["payload"]["proposal_id"]
        else:
            pending_rejected_proposal_id = None
        if event["event_type"] == "close_summary_generated":
            has_close_summary[event["session_id"]] = True
        if event["event_type"] == "plan_generated":
            for referenced_session_id in event["payload"]["session_ids"]:
                if referenced_session_id not in created_session_ids:
                    raise StateValidationError(
                        f"plan_generated references unknown session: {referenced_session_id}"
                    )
                if session_status.get(referenced_session_id) != "closed":
                    raise StateValidationError(
                        f"plan_generated references non-closed session: {referenced_session_id}"
                    )
        if event["event_type"] == "session_closed":
            session_status[event["session_id"]] = "closed"
        if event["event_type"] in {"session_resumed", "session_closed"}:
            proposal_id = active_proposal_by_session.get(event["session_id"])
            if proposal_id:
                disabled_proposals.add(proposal_id)
                target_id = issued_proposals[proposal_id]["target_id"]
                if decision_status.get(target_id) == "proposed":
                    decision_status[target_id] = "unresolved"
                active_proposal_by_session[event["session_id"]] = None
        elif event["event_type"] == "decision_invalidated":
            invalidated_id = event["payload"]["decision_id"]
            for candidate_session_id, proposal_id in list(active_proposal_by_session.items()):
                if proposal_id and issued_proposals.get(proposal_id, {}).get("target_id") == invalidated_id:
                    disabled_proposals.add(proposal_id)
                    active_proposal_by_session[candidate_session_id] = None
        if event["project_version_after"] <= previous_version:
            raise StateValidationError("event log project_version_after must be strictly increasing")
        previous_version = event["project_version_after"]


def _validate_event_log_proposal_lifecycle(
    event: dict[str, Any],
    issued_proposals: dict[str, dict[str, str]],
    active_proposal_by_session: dict[str, str | None],
    disabled_proposals: set[str],
    accepted_proposals: set[str],
    rejected_proposals: set[str],
) -> None:
    event_type = event["event_type"]
    payload = event["payload"]
    if event_type == "proposal_issued":
        proposal = payload["proposal"]
        proposal_id = proposal["proposal_id"]
        if proposal_id in issued_proposals:
            raise StateValidationError(f"duplicate proposal_id: {proposal_id}")
        issued_proposals[proposal_id] = {
            "origin_session_id": proposal["origin_session_id"],
            "target_id": proposal["target_id"],
            "target_type": proposal["target_type"],
        }
        active_proposal_by_session[event["session_id"]] = proposal_id
    elif event_type in {"proposal_accepted", "proposal_rejected"}:
        proposal_id = payload["proposal_id"]
        issued = issued_proposals.get(proposal_id)
        if issued is None:
            raise StateValidationError(f"{event_type} references unknown proposal {proposal_id}")
        if event_type == "proposal_accepted" and proposal_id in accepted_proposals:
            raise StateValidationError(f"duplicate proposal_accepted for {proposal_id}")
        if event_type == "proposal_rejected" and proposal_id in rejected_proposals:
            raise StateValidationError(f"duplicate proposal_rejected for {proposal_id}")
        if proposal_id in disabled_proposals:
            raise StateValidationError(f"{event_type} references inactive proposal {proposal_id}")
        if payload["origin_session_id"] != issued["origin_session_id"]:
            raise StateValidationError("proposal response origin_session_id does not match issued proposal")
        if payload["target_id"] != issued["target_id"]:
            raise StateValidationError("proposal response target_id does not match issued proposal")
        if payload["target_type"] != issued["target_type"]:
            raise StateValidationError("proposal response target_type does not match issued proposal")
        if event_type == "proposal_accepted":
            accepted_proposal_id = payload["accepted_answer"].get("proposal_id")
            if accepted_proposal_id != proposal_id:
                raise StateValidationError("accepted_answer.proposal_id must match payload.proposal_id")
            accepted_proposals.add(proposal_id)
            disabled_proposals.add(proposal_id)
            active_proposal_by_session[payload["origin_session_id"]] = None
        else:
            rejected_proposals.add(proposal_id)


def _validate_event_log_decision_transition(
    event: dict[str, Any],
    decision_status: dict[str, str],
    *,
    accepts_immediate_rejected_proposal: bool = False,
) -> None:
    event_type = event["event_type"]
    payload = event["payload"]
    if event_type == "proposal_issued":
        decision_id = payload["proposal"]["target_id"]
        _require_event_decision_status(decision_id, decision_status, {"unresolved", "rejected", "blocked"}, event_type)
        decision_status[decision_id] = "proposed"
    elif event_type == "proposal_rejected":
        decision_id = payload["target_id"]
        _require_event_decision_status(decision_id, decision_status, {"proposed"}, event_type)
        decision_status[decision_id] = "rejected"
    elif event_type == "proposal_accepted":
        decision_id = payload["target_id"]
        allowed = {"proposed"}
        if accepts_immediate_rejected_proposal:
            allowed.add("rejected")
        _require_event_decision_status(decision_id, decision_status, allowed, event_type)
        decision_status[decision_id] = "accepted"
    elif event_type == "decision_deferred":
        decision_id = payload["decision_id"]
        _require_event_decision_status(
            decision_id, decision_status, {"unresolved", "proposed", "rejected", "blocked"}, event_type
        )
        decision_status[decision_id] = "deferred"
    elif event_type == "decision_resolved_by_evidence":
        decision_id = payload["decision_id"]
        _require_event_decision_status(
            decision_id, decision_status, {"unresolved", "proposed", "rejected", "blocked"}, event_type
        )
        decision_status[decision_id] = "resolved-by-evidence"
    elif event_type == "decision_invalidated":
        target_id = payload["decision_id"]
        invalidating_id = payload["invalidated_by_decision_id"]
        _require_event_decision_status(
            invalidating_id,
            decision_status,
            FINAL_INVALIDATING_STATUSES,
            event_type,
        )
        if decision_status[target_id] == "invalidated":
            raise StateValidationError(f"decision {target_id} is already invalidated")
        decision_status[target_id] = "invalidated"


def _require_event_decision_status(
    decision_id: str, decision_status: dict[str, str], allowed: set[str], event_type: str
) -> None:
    status = decision_status[decision_id]
    if status not in allowed:
        allowed_values = ", ".join(sorted(allowed))
        raise StateValidationError(
            f"{event_type} cannot target decision {decision_id} with status {status}; "
            f"allowed statuses: {allowed_values}"
        )


def _has_final_invalidating_chain(
    decision_id: str,
    decisions_by_id: dict[str, dict[str, Any]],
    *,
    seen: set[str],
) -> bool:
    if decision_id in seen:
        return False
    seen.add(decision_id)
    decision = decisions_by_id.get(decision_id)
    if decision is None:
        return False
    if decision["status"] in FINAL_INVALIDATING_STATUSES:
        return True
    if decision["status"] != "invalidated":
        return False
    invalidated_by = decision.get("invalidated_by")
    if not isinstance(invalidated_by, dict):
        return False
    invalidating_id = invalidated_by.get("decision_id")
    if not invalidating_id:
        return False
    return _has_final_invalidating_chain(invalidating_id, decisions_by_id, seen=seen)


def _validate_event_log_session_decision_binding(
    event: dict[str, Any], session_decision_ids: dict[str, set[str]]
) -> None:
    event_type = event["event_type"]
    session_id = event["session_id"]
    if event_type in {
        "decision_enriched",
        "question_asked",
        "proposal_issued",
        "proposal_accepted",
        "proposal_rejected",
        "decision_deferred",
        "decision_resolved_by_evidence",
    }:
        for decision_id in _decision_refs_in_event(event):
            if decision_id not in session_decision_ids[session_id]:
                raise StateValidationError(
                    f"{event_type} references decision {decision_id} not bound to session {session_id}"
                )
    elif event_type == "decision_invalidated":
        invalidating_id = event["payload"]["invalidated_by_decision_id"]
        if invalidating_id not in session_decision_ids[session_id]:
            raise StateValidationError(
                f"decision_invalidated references invalidating decision {invalidating_id} "
                f"not bound to session {session_id}"
            )


def _decision_refs_in_event(event: dict[str, Any]) -> list[str]:
    event_type = event["event_type"]
    payload = event["payload"]
    if event_type in {"decision_enriched", "question_asked", "decision_deferred", "decision_resolved_by_evidence"}:
        return [payload["decision_id"]]
    if event_type == "proposal_issued":
        return [payload["proposal"]["target_id"]]
    if event_type in {"proposal_accepted", "proposal_rejected"}:
        return [payload["target_id"]]
    if event_type == "decision_invalidated":
        return [payload["decision_id"], payload["invalidated_by_decision_id"]]
    return []


def _require_non_empty_string(value: Any, label: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise StateValidationError(f"{label} must be a non-empty string")


def _require_dict(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise StateValidationError(f"{label} must be an object")
    return value


def _require_list(value: Any, label: str) -> None:
    if not isinstance(value, list):
        raise StateValidationError(f"{label} must be a list")


def _require_enum(value: Any, allowed: set[str], label: str) -> None:
    if value not in allowed:
        choices = ", ".join(sorted(allowed))
        raise StateValidationError(f"{label} must be one of: {choices}")


def _recomputed_counts(decisions: list[dict[str, Any]]) -> dict[str, int]:
    counts = {"p0_now_open": 0, "p1_now_open": 0, "p2_open": 0, "blocked": 0, "deferred": 0}
    for decision in decisions:
        status = decision["status"]
        if decision["priority"] == "P0" and decision["frontier"] == "now" and status in OPEN_DECISION_STATUSES:
            counts["p0_now_open"] += 1
        if decision["priority"] == "P1" and decision["frontier"] == "now" and status in OPEN_DECISION_STATUSES:
            counts["p1_now_open"] += 1
        if decision["priority"] == "P2" and status in OPEN_DECISION_STATUSES:
            counts["p2_open"] += 1
        if status == "blocked":
            counts["blocked"] += 1
        if status == "deferred":
            counts["deferred"] += 1
    return counts

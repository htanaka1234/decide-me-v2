from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from decide_me.classification import classify_session
from decide_me.exports import export_adr
from decide_me.events import utc_now
from decide_me.interview import advance_session, handle_reply
from decide_me.lifecycle import close_session, create_session, list_sessions, resume_session, show_session
from decide_me.planner import generate_plan
from decide_me.protocol import (
    accept_proposal,
    answer_proposal,
    defer_decision,
    discover_decision,
    enrich_decision,
    invalidate_decision,
    issue_proposal,
    reject_proposal,
    resolve_by_evidence,
    update_classification,
)
from decide_me.store import bootstrap_runtime, rebuild_and_persist, transact, validate_runtime


class RuntimeFlowTests(unittest.TestCase):
    def test_parallel_sessions_do_not_accept_stale_plain_ok(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Exercise stale proposal handling",
                current_milestone="MVP",
            )
            s1 = create_session(ai_dir, context="Auth thread")["session"]["id"]
            s2 = create_session(ai_dir, context="Audit thread")["session"]["id"]

            discover_decision(
                ai_dir,
                s1,
                {
                    "id": "D-001",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            discover_decision(
                ai_dir,
                s2,
                {
                    "id": "D-002",
                    "title": "Audit sink",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should audit logs work?",
                },
            )

            proposal = issue_proposal(
                ai_dir,
                s1,
                decision_id="D-001",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )
            issue_proposal(
                ai_dir,
                s2,
                decision_id="D-002",
                question="Use the product database?",
                recommendation="Use the product database.",
                why="Cheaper for the milestone.",
                if_not="A separate sink becomes in scope now.",
            )
            accept_proposal(ai_dir, s2)

            with self.assertRaisesRegex(ValueError, "stale"):
                accept_proposal(ai_dir, s1)

            accepted = accept_proposal(ai_dir, s1, proposal_id=proposal["proposal_id"])
            self.assertEqual("accepted", accepted["status"])

            rebuild_and_persist(ai_dir)
            self.assertEqual([], validate_runtime(ai_dir))

    def test_cross_session_explicit_proposal_acceptance_is_rejected(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep proposal ownership session scoped",
                current_milestone="MVP",
            )
            owning_session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            other_session_id = create_session(ai_dir, context="Audit thread")["session"]["id"]

            discover_decision(
                ai_dir,
                owning_session_id,
                {
                    "id": "D-ownership",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                owning_session_id,
                decision_id="D-ownership",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )

            with self.assertRaisesRegex(ValueError, "belongs to session"):
                accept_proposal(ai_dir, other_session_id, proposal_id=proposal["proposal_id"])

            shown = show_session(ai_dir, owning_session_id)
            active = shown["session"]["working_state"]["active_proposal"]
            self.assertEqual(proposal["proposal_id"], active["proposal_id"])
            self.assertTrue(active["is_active"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_inactive_proposal_cannot_be_reused_after_accept_or_reject(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject inactive proposal reuse",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-reuse-accept",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-reuse-accept",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )
            accept_proposal(ai_dir, session_id)

            with self.assertRaisesRegex(ValueError, "inactive"):
                accept_proposal(ai_dir, session_id, proposal_id=proposal["proposal_id"])
            with self.assertRaisesRegex(ValueError, "inactive"):
                reject_proposal(ai_dir, session_id, proposal_id=proposal["proposal_id"], reason="No")

            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-reuse-reject",
                    "title": "Audit sink",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "question": "Where should audit logs land?",
                },
            )
            rejected = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-reuse-reject",
                question="Use the product database?",
                recommendation="Use the product database.",
                why="Cheaper for the milestone.",
                if_not="A separate sink becomes in scope now.",
            )
            reject_proposal(ai_dir, session_id, reason="No")

            with self.assertRaisesRegex(ValueError, "inactive"):
                accept_proposal(ai_dir, session_id, proposal_id=rejected["proposal_id"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_resume_session_makes_previous_proposal_unusable(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject proposal reuse after resume",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-resume",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-resume",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )

            resume_session(ai_dir, session_id)

            with self.assertRaisesRegex(ValueError, "inactive"):
                accept_proposal(ai_dir, session_id, proposal_id=proposal["proposal_id"])
            with self.assertRaisesRegex(ValueError, "inactive"):
                reject_proposal(ai_dir, session_id, reason="No")
            with self.assertRaisesRegex(ValueError, "inactive"):
                answer_proposal(ai_dir, session_id, answer_summary="Use passwords.")

            turn = advance_session(ai_dir, session_id, repo_root=tmp)
            self.assertEqual("question", turn["status"])
            self.assertEqual("D-resume", turn["decision_id"])
            self.assertNotEqual(proposal["proposal_id"], turn["proposal_id"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_closed_session_rejects_proposal_replies(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep closed sessions read-only",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Retention thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-closed",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "question": "How long should audit logs be retained?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-closed",
                question="Use 30 days?",
                recommendation="Use 30 days.",
                why="Keeps MVP scope small.",
                if_not="Longer retention expands compliance scope.",
            )
            close_session(ai_dir, session_id)

            with self.assertRaisesRegex(ValueError, "closed"):
                accept_proposal(ai_dir, session_id, proposal_id=proposal["proposal_id"])
            with self.assertRaisesRegex(ValueError, "closed"):
                reject_proposal(ai_dir, session_id, proposal_id=proposal["proposal_id"], reason="No")
            with self.assertRaisesRegex(ValueError, "closed"):
                handle_reply(ai_dir, session_id, "Use 90 days.", repo_root=tmp)
            close_summary = show_session(ai_dir, session_id)["session"]["close_summary"]
            self.assertEqual("unresolved", close_summary["unresolved_blockers"][0]["status"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_empty_session_does_not_claim_project_open_decisions(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep empty sessions unbound",
                current_milestone="MVP",
            )
            owning_session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            empty_session_id = create_session(ai_dir, context="New thread")["session"]["id"]
            discover_decision(
                ai_dir,
                owning_session_id,
                {
                    "id": "D-open",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )

            turn = advance_session(ai_dir, empty_session_id, repo_root=tmp)
            self.assertEqual("unbound", turn["status"])
            self.assertIn("No decisions are bound", turn["message"])
            self.assertEqual([], show_session(ai_dir, empty_session_id)["session"]["session"]["decision_ids"])
            self.assertEqual(["D-open"], show_session(ai_dir, owning_session_id)["session"]["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_advance_session_returns_stale_prompt_for_active_stale_proposal(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Handle active stale proposals",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            other_session_id = create_session(ai_dir, context="Other thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-stale",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-stale",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )
            discover_decision(
                ai_dir,
                other_session_id,
                {
                    "id": "D-unrelated",
                    "title": "Unrelated decision",
                    "priority": "P2",
                    "frontier": "later",
                    "domain": "ops",
                    "question": "Should this make the proposal stale?",
                },
            )

            turn = advance_session(ai_dir, session_id, repo_root=tmp)

            self.assertEqual("stale-proposal", turn["status"])
            self.assertEqual(proposal["proposal_id"], turn["proposal_id"])
            self.assertEqual("project-version-changed", turn["stale_reason"])
            self.assertIn("Accept P-", turn["message"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_terminal_decisions_cannot_be_deferred(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Protect terminal decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Decision thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-accepted-terminal",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-accepted-terminal",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )
            accept_proposal(ai_dir, session_id)

            with self.assertRaisesRegex(ValueError, "accepted"):
                defer_decision(
                    ai_dir,
                    session_id,
                    decision_id="D-accepted-terminal",
                    reason="Move it later.",
                )

            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-evidence-terminal",
                    "title": "Existing auth flow",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "Which auth flow already exists?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                session_id,
                decision_id="D-evidence-terminal",
                source="codebase",
                summary="Use the existing magic-link flow.",
                evidence_refs=["app/auth.py"],
            )

            with self.assertRaisesRegex(ValueError, "resolved-by-evidence"):
                defer_decision(
                    ai_dir,
                    session_id,
                    decision_id="D-evidence-terminal",
                    reason="Move it later.",
                )
            self.assertEqual([], validate_runtime(ai_dir))

    def test_active_proposal_blocks_other_decision_mutations(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Protect active proposal state",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Decision thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-active",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-other",
                    "title": "Existing auth flow",
                    "priority": "P1",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "Which auth flow already exists?",
                    "resolvable_by": "codebase",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-active",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )

            with self.assertRaisesRegex(ValueError, "active proposal"):
                issue_proposal(
                    ai_dir,
                    session_id,
                    decision_id="D-other",
                    question="Use the existing flow?",
                    recommendation="Use the existing flow.",
                    why="It is already implemented.",
                    if_not="A new flow expands scope.",
                )
            with self.assertRaisesRegex(ValueError, "proposed"):
                issue_proposal(
                    ai_dir,
                    session_id,
                    decision_id="D-active",
                    question="Use passwords?",
                    recommendation="Use passwords.",
                    why="Enterprise users expect it.",
                    if_not="Magic links may be unfamiliar.",
                )
            with self.assertRaisesRegex(ValueError, "active proposal"):
                defer_decision(ai_dir, session_id, decision_id="D-other", reason="Move it later.")
            with self.assertRaisesRegex(ValueError, "active proposal"):
                resolve_by_evidence(
                    ai_dir,
                    session_id,
                    decision_id="D-other",
                    source="codebase",
                    summary="Use the existing magic-link flow.",
                    evidence_refs=["app/auth.py"],
                )

            shown = show_session(ai_dir, session_id)["session"]
            active = shown["working_state"]["active_proposal"]
            self.assertEqual(proposal["proposal_id"], active["proposal_id"])
            self.assertTrue(active["is_active"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_issue_proposal_rejects_empty_text_fields(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject empty proposal text",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Decision thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-empty-proposal",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            kwargs = {
                "decision_id": "D-empty-proposal",
                "question": "Use magic links?",
                "recommendation": "Use magic links.",
                "why": "Smaller MVP surface area.",
                "if_not": "Passwords expand auth scope.",
            }

            for field in ("question", "recommendation", "why", "if_not"):
                with self.subTest(field=field):
                    candidate = dict(kwargs)
                    candidate[field] = " "
                    with self.assertRaisesRegex(ValueError, field):
                        issue_proposal(ai_dir, session_id, **candidate)

            self.assertEqual([], validate_runtime(ai_dir))

    def test_reason_commands_require_non_empty_reason(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject empty reasons",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Decision thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-empty-reason",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )

            with self.assertRaisesRegex(ValueError, "reason"):
                defer_decision(ai_dir, session_id, decision_id="D-empty-reason", reason="")

            issue_proposal(
                ai_dir,
                session_id,
                decision_id="D-empty-reason",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP surface area.",
                if_not="Passwords expand auth scope.",
            )
            with self.assertRaisesRegex(ValueError, "reason"):
                reject_proposal(ai_dir, session_id, reason=" ")

            self.assertEqual([], validate_runtime(ai_dir))

    def test_enrich_decision_accepts_individual_append_fields(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Enrich decisions incrementally",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Decision thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-enrich",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )

            enriched = enrich_decision(ai_dir, session_id, decision_id="D-enrich", notes_append=["note"])
            self.assertIn("note", enriched["notes"])
            enriched = enrich_decision(
                ai_dir,
                session_id,
                decision_id="D-enrich",
                revisit_triggers_append=["when enterprise launches"],
            )
            self.assertIn("when enterprise launches", enriched["revisit_triggers"])
            enriched = enrich_decision(
                ai_dir,
                session_id,
                decision_id="D-enrich",
                context_append="Extra context.",
            )
            self.assertEqual("Extra context.", enriched["context"])

            event_log = (Path(ai_dir) / "event-log.jsonl").read_text(encoding="utf-8")
            self.assertNotIn('"context_append": null', event_log)
            self.assertEqual([], validate_runtime(ai_dir))

    def test_resolve_by_evidence_rejects_unknown_source(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep evidence sources typed",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Evidence thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-evidence-source",
                    "title": "Existing auth flow",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "Which auth flow already exists?",
                    "resolvable_by": "codebase",
                },
            )

            with self.assertRaisesRegex(ValueError, "invalid evidence source"):
                resolve_by_evidence(
                    ai_dir,
                    session_id,
                    decision_id="D-evidence-source",
                    source="aliens",
                    summary="Found elsewhere.",
                    evidence_refs=[],
                )
            self.assertEqual([], validate_runtime(ai_dir))

    def test_decision_level_commands_are_session_bound(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep decision commands session scoped",
                current_milestone="MVP",
            )
            owning_session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            other_session_id = create_session(ai_dir, context="Other thread")["session"]["id"]
            discover_decision(
                ai_dir,
                owning_session_id,
                {
                    "id": "D-bound",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )

            with self.assertRaisesRegex(ValueError, "not bound"):
                defer_decision(
                    ai_dir,
                    other_session_id,
                    decision_id="D-bound",
                    reason="Move it later.",
                )
            self.assertEqual(["D-bound"], show_session(ai_dir, owning_session_id)["session"]["session"]["decision_ids"])
            self.assertEqual([], show_session(ai_dir, other_session_id)["session"]["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_discover_decision_rejects_existing_decision_id(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject duplicate decisions",
                current_milestone="MVP",
            )
            first_session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            second_session_id = create_session(ai_dir, context="Other thread")["session"]["id"]
            discover_decision(
                ai_dir,
                first_session_id,
                {
                    "id": "D-duplicate",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )

            with self.assertRaisesRegex(ValueError, "already exists"):
                discover_decision(
                    ai_dir,
                    second_session_id,
                    {
                        "id": "D-duplicate",
                        "title": "Overwrite auth mode",
                        "status": "unresolved",
                        "question": "Can this overwrite the first decision?",
                    },
                )
            self.assertEqual([], show_session(ai_dir, second_session_id)["session"]["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_discover_decision_rejects_terminal_or_runtime_payloads(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep discovery from bypassing state transitions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Discovery thread")["session"]["id"]

            with self.assertRaisesRegex(ValueError, "statuses"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": "D-injected-accepted",
                        "title": "Injected accepted",
                        "status": "accepted",
                    },
                )
            with self.assertRaisesRegex(ValueError, "statuses"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": "D-injected-evidence",
                        "title": "Injected evidence",
                        "status": "resolved-by-evidence",
                    },
                )
            with self.assertRaisesRegex(ValueError, "accepted_answer"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": "D-injected-answer",
                        "title": "Injected answer",
                        "accepted_answer": {"summary": "Already decided."},
                    },
                )
            with self.assertRaisesRegex(ValueError, "invalidated_by"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": "D-injected-invalidated",
                        "title": "Injected invalidation",
                        "invalidated_by": {"decision_id": "D-other"},
                    },
                )
            self.assertEqual([], show_session(ai_dir, session_id)["session"]["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_closed_session_rejects_low_level_mutations(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep closed sessions read-only",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Closed thread")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-closed-low-level",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "How should auth work?",
                },
            )
            close_session(ai_dir, session_id)

            with self.assertRaisesRegex(ValueError, "closed"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": "D-after-close",
                        "title": "Late decision",
                        "question": "Should this be allowed?",
                    },
                )
            with self.assertRaisesRegex(ValueError, "closed"):
                resolve_by_evidence(
                    ai_dir,
                    session_id,
                    decision_id="D-closed-low-level",
                    source="codebase",
                    summary="Resolved late.",
                    evidence_refs=["app/auth.py"],
                )
            with self.assertRaisesRegex(ValueError, "closed"):
                defer_decision(
                    ai_dir,
                    session_id,
                    decision_id="D-closed-low-level",
                    reason="Move it later.",
                )
            with self.assertRaisesRegex(ValueError, "closed"):
                update_classification(
                    ai_dir,
                    session_id,
                    domain="technical",
                    abstraction_level="architecture",
                )
            self.assertEqual([], validate_runtime(ai_dir))

    def test_close_sessions_generate_plan_and_adr(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Generate an action plan",
                current_milestone="MVP",
            )

            s1 = create_session(ai_dir, context="Auth decisions")["session"]["id"]
            discover_decision(
                ai_dir,
                s1,
                {
                    "id": "D-001",
                    "title": "Auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "kind": "choice",
                    "question": "How should auth work?",
                },
            )
            update_classification(
                ai_dir,
                s1,
                domain="technical",
                abstraction_level="architecture",
                search_terms=["auth"],
            )
            resolve_by_evidence(
                ai_dir,
                s1,
                decision_id="D-001",
                source="codebase",
                summary="Use the existing magic-link flow.",
                evidence_refs=["app/auth.py"],
            )
            close_session(ai_dir, s1)

            s2 = create_session(ai_dir, context="Audit decisions")["session"]["id"]
            discover_decision(
                ai_dir,
                s2,
                {
                    "id": "D-002",
                    "title": "Audit sink",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "kind": "choice",
                    "question": "Where should audit logs land?",
                },
            )
            issue_proposal(
                ai_dir,
                s2,
                decision_id="D-002",
                question="Use the product database?",
                recommendation="Use the product database.",
                why="Lowest operational overhead.",
                if_not="A separate sink becomes in scope now.",
            )
            accept_proposal(ai_dir, s2)
            close_session(ai_dir, s2)

            plan = generate_plan(ai_dir, [s1, s2])
            self.assertEqual("action-plan", plan["status"])
            self.assertEqual("ready", plan["action_plan"]["readiness"])
            self.assertEqual("D-001", plan["action_plan"]["implementation_ready_slices"][0]["decision_id"])
            self.assertEqual("codebase", plan["action_plan"]["implementation_ready_slices"][0]["evidence_source"])
            self.assertTrue(Path(plan["export_path"]).exists())

            adr_path = export_adr(ai_dir, "D-001")
            self.assertTrue(adr_path.exists())
            self.assertEqual([], validate_runtime(ai_dir))

    def test_project_wide_invalidation_hides_closed_decision_outputs(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Hide invalidated decisions from normal outputs",
                current_milestone="MVP",
            )

            old_session_id = create_session(ai_dir, context="Legacy auth decision")["session"]["id"]
            discover_decision(
                ai_dir,
                old_session_id,
                {
                    "id": "D-100",
                    "title": "Legacy auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "kind": "choice",
                    "question": "Should the MVP use magic links?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                old_session_id,
                decision_id="D-100",
                source="codebase",
                summary="Use the existing magic-link flow.",
                evidence_refs=["app/auth.py"],
            )
            close_session(ai_dir, old_session_id)

            replacement_session_id = create_session(ai_dir, context="Replacement auth decision")["session"]["id"]
            discover_decision(
                ai_dir,
                replacement_session_id,
                {
                    "id": "D-101",
                    "title": "Replacement auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "kind": "choice",
                    "question": "Should the MVP use passwords?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                replacement_session_id,
                decision_id="D-101",
                source="codebase",
                summary="Use the password flow.",
                evidence_refs=["app/password_auth.py"],
            )
            close_session(ai_dir, replacement_session_id)

            invalidated = invalidate_decision(
                ai_dir,
                replacement_session_id,
                decision_id="D-100",
                invalidated_by_decision_id="D-101",
                reason="Superseded by the later auth decision.",
            )
            self.assertEqual("ok", invalidated["status"])

            rebuild_and_persist(ai_dir)

            shown = show_session(ai_dir, old_session_id)
            self.assertEqual([], shown["session"]["session"]["decision_ids"])
            self.assertEqual([], shown["session"]["close_summary"]["accepted_decisions"])

            plan = generate_plan(ai_dir, [old_session_id, replacement_session_id])
            self.assertEqual("action-plan", plan["status"])
            self.assertEqual(["D-101"], [item["decision_id"] for item in plan["action_plan"]["action_slices"]])
            self.assertEqual(
                ["D-101"],
                [item["decision_id"] for item in plan["action_plan"]["implementation_ready_slices"]],
            )

            with self.assertRaisesRegex(ValueError, "not accepted"):
                export_adr(ai_dir, "D-100")

            event_log = (Path(ai_dir) / "event-log.jsonl").read_text(encoding="utf-8")
            self.assertIn('"event_type": "decision_invalidated"', event_log)
            self.assertEqual([], validate_runtime(ai_dir))

    def test_invalidation_recomputes_close_summary_readiness(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Recompute stale close summary readiness",
                current_milestone="MVP",
            )

            blocker_session_id = create_session(ai_dir, context="Blocked work")["session"]["id"]
            discover_decision(
                ai_dir,
                blocker_session_id,
                {
                    "id": "D-blocker",
                    "title": "Blocking decision",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "What blocks the MVP?",
                },
            )
            closed_blocker = close_session(ai_dir, blocker_session_id)
            self.assertEqual("blocked", closed_blocker["close_summary"]["readiness"])

            replacement_session_id = create_session(ai_dir, context="Replacement")["session"]["id"]
            discover_decision(
                ai_dir,
                replacement_session_id,
                {
                    "id": "D-replacement",
                    "title": "Replacement decision",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "What supersedes the blocker?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                replacement_session_id,
                decision_id="D-replacement",
                source="codebase",
                summary="Use the replacement.",
                evidence_refs=["app/replacement.py"],
            )
            invalidate_decision(
                ai_dir,
                replacement_session_id,
                decision_id="D-blocker",
                invalidated_by_decision_id="D-replacement",
                reason="Superseded by a replacement decision.",
            )

            shown = show_session(ai_dir, blocker_session_id)["session"]
            self.assertEqual("ready", shown["close_summary"]["readiness"])
            self.assertEqual([], shown["close_summary"]["unresolved_blockers"])
            self.assertEqual([], validate_runtime(ai_dir))

            risk_session_id = create_session(ai_dir, context="Risk work")["session"]["id"]
            discover_decision(
                ai_dir,
                risk_session_id,
                {
                    "id": "D-risk",
                    "title": "Risk decision",
                    "kind": "risk",
                    "priority": "P1",
                    "frontier": "now",
                    "domain": "ops",
                    "question": "What risk remains?",
                },
            )
            closed_risk = close_session(ai_dir, risk_session_id)
            self.assertEqual("conditional", closed_risk["close_summary"]["readiness"])
            invalidate_decision(
                ai_dir,
                replacement_session_id,
                decision_id="D-risk",
                invalidated_by_decision_id="D-replacement",
                reason="Superseded by a replacement decision.",
            )

            shown_risk = show_session(ai_dir, risk_session_id)["session"]
            self.assertEqual("ready", shown_risk["close_summary"]["readiness"])
            self.assertEqual([], shown_risk["close_summary"]["unresolved_risks"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_invalidation_does_not_bind_invalidating_decision_to_unrelated_session(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Keep invalidation project-wide",
                current_milestone="MVP",
            )
            old_session_id = create_session(ai_dir, context="Old decision")["session"]["id"]
            discover_decision(
                ai_dir,
                old_session_id,
                {
                    "id": "D-old",
                    "title": "Old auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "Should the MVP use magic links?",
                },
            )
            close_session(ai_dir, old_session_id)

            new_session_id = create_session(ai_dir, context="New decision")["session"]["id"]
            discover_decision(
                ai_dir,
                new_session_id,
                {
                    "id": "D-new",
                    "title": "New auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "question": "Should the MVP use passwords?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                new_session_id,
                decision_id="D-new",
                source="codebase",
                summary="Use the password flow.",
                evidence_refs=["app/password_auth.py"],
            )

            with self.assertRaisesRegex(ValueError, "not bound"):
                invalidate_decision(
                    ai_dir,
                    old_session_id,
                    decision_id="D-old",
                    invalidated_by_decision_id="D-new",
                    reason="Superseded by the password decision.",
                )

            invalidate_decision(
                ai_dir,
                new_session_id,
                decision_id="D-old",
                invalidated_by_decision_id="D-new",
                reason="Superseded by the password decision.",
            )

            old_session = show_session(ai_dir, old_session_id)["session"]
            self.assertEqual([], old_session["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_invalidation_chain_remains_valid(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Allow chained replacement decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Replacement chain")["session"]["id"]
            for decision_id in ("D-old", "D-replacement", "D-final"):
                discover_decision(
                    ai_dir,
                    session_id,
                    {
                        "id": decision_id,
                        "title": decision_id,
                        "priority": "P0",
                        "frontier": "now",
                        "domain": "technical",
                        "question": f"What should {decision_id} decide?",
                    },
                )
                issue_proposal(
                    ai_dir,
                    session_id,
                    decision_id=decision_id,
                    question=f"Use {decision_id}?",
                    recommendation=f"Use {decision_id}.",
                    why="It is the current replacement.",
                    if_not="Keep the earlier decision.",
                )
                accept_proposal(ai_dir, session_id)

            invalidate_decision(
                ai_dir,
                session_id,
                decision_id="D-old",
                invalidated_by_decision_id="D-replacement",
                reason="Superseded by the replacement.",
            )
            invalidate_decision(
                ai_dir,
                session_id,
                decision_id="D-replacement",
                invalidated_by_decision_id="D-final",
                reason="Superseded by the final replacement.",
            )

            shown = show_session(ai_dir, session_id)["session"]
            self.assertEqual(["D-final"], shown["session"]["decision_ids"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_advance_session_skips_invalidated_active_proposal(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Skip invalidated active proposals",
                current_milestone="MVP",
            )

            questioned_session_id = create_session(ai_dir, context="Auth thread")["session"]["id"]
            discover_decision(
                ai_dir,
                questioned_session_id,
                {
                    "id": "D-110",
                    "title": "Old auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "kind": "choice",
                    "question": "Should the MVP use magic links?",
                },
            )
            discover_decision(
                ai_dir,
                questioned_session_id,
                {
                    "id": "D-111",
                    "title": "Audit sink",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "kind": "choice",
                    "question": "Where should audit logs land?",
                },
            )
            proposal = issue_proposal(
                ai_dir,
                questioned_session_id,
                decision_id="D-110",
                question="Use magic links?",
                recommendation="Use magic links.",
                why="Smaller MVP scope.",
                if_not="Passwords expand scope now.",
            )

            replacement_session_id = create_session(ai_dir, context="Replacement auth thread")["session"]["id"]
            discover_decision(
                ai_dir,
                replacement_session_id,
                {
                    "id": "D-112",
                    "title": "Replacement auth mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "kind": "choice",
                    "question": "Should the MVP use passwords?",
                    "resolvable_by": "codebase",
                },
            )
            resolve_by_evidence(
                ai_dir,
                replacement_session_id,
                decision_id="D-112",
                source="codebase",
                summary="Use the password flow.",
                evidence_refs=["app/password_auth.py"],
            )

            invalidate_decision(
                ai_dir,
                replacement_session_id,
                decision_id="D-110",
                invalidated_by_decision_id="D-112",
                reason="Superseded by the accepted password auth decision.",
            )

            turn = advance_session(ai_dir, questioned_session_id, repo_root=tmp)
            self.assertEqual("question", turn["status"])
            self.assertEqual("D-111", turn["decision_id"])

            shown = show_session(ai_dir, questioned_session_id)
            self.assertEqual(["D-111"], shown["session"]["session"]["decision_ids"])
            self.assertEqual("D-111", shown["display"]["active_decision_id"])

            with self.assertRaisesRegex(ValueError, "invalidated"):
                accept_proposal(ai_dir, questioned_session_id, proposal_id=proposal["proposal_id"])

            self.assertEqual([], validate_runtime(ai_dir))

    def test_classification_search_and_lazy_compatibility_backfill(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Exercise taxonomy-aware search",
                current_milestone="MVP",
            )

            session = create_session(ai_dir, context="Authentication choices")
            session_id = session["session"]["id"]
            classification = classify_session(
                ai_dir,
                session_id,
                domain="technical",
                abstraction_level="architecture",
                candidate_terms=["email link"],
                source_refs=["latest_summary"],
            )
            self.assertEqual("technical", classification["classification"]["domain"])
            self.assertIn("latest_summary", classification["classification"]["source_refs"])

            listing = list_sessions(
                ai_dir,
                domains=["technical"],
                abstraction_levels=["architecture"],
                tag_terms=["email link"],
            )
            self.assertEqual(1, listing["count"])
            self.assertEqual(session_id, listing["sessions"][0]["session_id"])

            close_session(ai_dir, session_id)

            now = utc_now()

            def builder(bundle: dict[str, object]) -> list[dict[str, object]]:
                return [
                    {
                        "session_id": session_id,
                        "event_type": "taxonomy_extended",
                        "payload": {
                            "nodes": [
                                {
                                    "id": "tag:magic-links",
                                    "axis": "tag",
                                    "label": "magic links",
                                    "aliases": ["authentication"],
                                    "parent_id": None,
                                    "replaced_by": [],
                                    "status": "active",
                                    "created_at": now,
                                    "updated_at": now,
                                },
                                {
                                    "id": "tag:email-link",
                                    "axis": "tag",
                                    "label": "email link",
                                    "aliases": [],
                                    "parent_id": None,
                                    "replaced_by": ["tag:magic-links"],
                                    "status": "replaced",
                                    "created_at": bundle["taxonomy_state"]["nodes"][-1]["created_at"],
                                    "updated_at": now,
                                },
                            ]
                        },
                    }
                ]

            transact(ai_dir, builder)

            display = show_session(ai_dir, session_id)
            self.assertIn("tag:magic-links", display["session"]["classification"]["compatibility_tags"])
            self.assertIn("tag:magic-links", display["compatibility_tag_refs_added"])

            listing = list_sessions(ai_dir, tag_terms=["authentication"])
            self.assertEqual(1, listing["count"])
            self.assertGreaterEqual(len(listing["backfilled"]), 0)
            self.assertEqual([], validate_runtime(ai_dir))

    def test_advance_session_resolves_evidence_then_handles_ok_reply(self) -> None:
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app").mkdir()
            (root / "app" / "auth.py").write_text(
                "def login():\n    return 'magic link auth flow'\n",
                encoding="utf-8",
            )
            ai_dir = str(root / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Advance interview turns",
                current_milestone="MVP",
            )

            session_id = create_session(ai_dir, context="MVP decisions")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-001",
                    "title": "Magic link auth",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "resolvable_by": "codebase",
                    "question": "Should the MVP use the existing magic-link flow?",
                    "context": "Use the current auth implementation if possible.",
                    "options": [{"summary": "Use the existing magic-link flow."}],
                },
            )
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-002",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "resolvable_by": "human",
                    "question": "How long should audit logs be retained?",
                    "context": "Retention affects compliance scope.",
                    "options": [{"summary": "Start with 30 days."}],
                },
            )

            turn = advance_session(ai_dir, session_id, repo_root=root)
            self.assertEqual("question", turn["status"])
            self.assertEqual("D-002", turn["decision_id"])
            self.assertEqual(1, len(turn["auto_resolved"]))
            self.assertEqual("D-001", turn["auto_resolved"][0]["decision_id"])
            self.assertIn("app/auth.py", turn["auto_resolved"][0]["evidence_refs"])
            self.assertIn("Resolved by evidence: D-001", turn["message"])

            reply = handle_reply(ai_dir, session_id, "OK", repo_root=root)
            self.assertEqual("accepted", reply["status"])
            self.assertEqual("complete", reply["next_turn"]["status"])
            self.assertIn("Accepted: D-002", reply["message"])
            self.assertIn("Next recommended action:", reply["message"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_accepts_freeform_alternative_answer(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Capture free-form answers",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Retention decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-010",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "resolvable_by": "human",
                    "question": "How long should audit logs be retained?",
                    "context": "Retention affects compliance scope.",
                    "options": [{"summary": "Start with 30 days."}],
                },
            )

            turn = advance_session(ai_dir, session_id, repo_root=tmp)
            self.assertEqual("question", turn["status"])

            reply = handle_reply(
                ai_dir,
                session_id,
                "Use 90 days because enterprise customers will expect it.",
                repo_root=tmp,
            )
            self.assertEqual("accepted", reply["status"])
            self.assertEqual(
                "Use 90 days because enterprise customers will expect it.",
                reply["decision"]["accepted_answer"]["summary"],
            )
            self.assertEqual("complete", reply["next_turn"]["status"])
            self.assertIn(
                "Accepted answer overrides the last recommendation.",
                reply["decision"]["notes"],
            )
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_rejects_negative_only_reply(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Reject proposal with free-form no",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Retention decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-011",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "resolvable_by": "human",
                    "question": "How long should audit logs be retained?",
                    "context": "Retention affects compliance scope.",
                    "options": [{"summary": "Start with 30 days."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=tmp)
            reply = handle_reply(ai_dir, session_id, "No", repo_root=tmp)
            self.assertEqual("rejected", reply["status"])
            self.assertIn("Rejected: D-011", reply["message"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_accepts_affirming_freeform_phrase(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Accept affirming phrase",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Retention decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-012",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "resolvable_by": "human",
                    "question": "How long should audit logs be retained?",
                    "context": "Retention affects compliance scope.",
                    "options": [{"summary": "Start with 30 days."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=tmp)
            reply = handle_reply(ai_dir, session_id, "Sounds good", repo_root=tmp)
            self.assertEqual("accepted", reply["status"])
            self.assertEqual("Start with 30 days.", reply["decision"]["accepted_answer"]["summary"])
            self.assertEqual("explicit", reply["decision"]["accepted_answer"]["accepted_via"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_extracts_constraints_and_follow_up_decisions(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Extract constraints and follow-up decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-020",
                    "title": "Authentication mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "resolvable_by": "human",
                    "question": "Should the MVP use magic links?",
                    "context": "Choose the initial authentication mode.",
                    "options": [{"summary": "Use magic links for the MVP."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=tmp)
            reply = handle_reply(
                ai_dir,
                session_id,
                "Sounds good, but only for enterprise tenants, and we also need password reset before launch.",
                repo_root=tmp,
            )
            self.assertEqual("accepted", reply["status"])
            self.assertEqual(
                "Use magic links for the MVP.",
                reply["decision"]["accepted_answer"]["summary"],
            )
            self.assertEqual(["only for enterprise tenants"], reply["captured_constraints"])
            self.assertEqual(1, len(reply["discovered_decisions"]))
            discovered = reply["discovered_decisions"][0]
            self.assertEqual("technical", discovered["domain"])
            self.assertEqual("choice", discovered["kind"])
            self.assertEqual("P0", discovered["priority"])
            self.assertEqual("now", discovered["frontier"])
            self.assertEqual("codebase", discovered["resolvable_by"])
            self.assertEqual("reversible", discovered["reversibility"])
            self.assertEqual(
                "How should we implement password reset before launch?",
                discovered["question"],
            )
            self.assertIn("Constraint: only for enterprise tenants", reply["decision"]["notes"])
            self.assertEqual("question", reply["next_turn"]["status"])
            self.assertEqual(discovered["id"], reply["next_turn"]["decision_id"])
            self.assertIn("Captured constraints:", reply["message"])
            self.assertIn("Discovered decisions:", reply["message"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_immediately_resolves_discovered_codebase_decision(self) -> None:
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app").mkdir()
            (root / "app" / "auth.py").write_text(
                "def send_password_reset(email):\n    return f'password reset sent to {email}'\n",
                encoding="utf-8",
            )
            ai_dir = str(root / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Immediately resolve discovered codebase decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-023",
                    "title": "Authentication mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "resolvable_by": "human",
                    "question": "Should the MVP use magic links?",
                    "context": "Choose the initial authentication mode.",
                    "options": [{"summary": "Use magic links for the MVP."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=root)
            reply = handle_reply(
                ai_dir,
                session_id,
                "Sounds good, and we also need password reset before launch.",
                repo_root=root,
            )
            self.assertEqual("accepted", reply["status"])
            self.assertEqual(1, len(reply["discovered_decisions"]))
            discovered = reply["discovered_decisions"][0]
            self.assertEqual("resolved-by-evidence", discovered["status"])
            self.assertEqual("codebase", discovered["resolved_by_evidence"]["source"])
            self.assertIn("app/auth.py", discovered["resolved_by_evidence"]["evidence_refs"])
            self.assertEqual(1, len(reply["auto_resolved"]))
            self.assertEqual(discovered["id"], reply["auto_resolved"][0]["decision_id"])
            self.assertEqual("complete", reply["next_turn"]["status"])
            self.assertEqual(discovered["id"], reply["next_turn"]["auto_resolved"][0]["decision_id"])
            self.assertIn("Resolved by evidence:", reply["message"])
            closed = close_session(ai_dir, session_id)
            slices = closed["close_summary"]["candidate_action_slices"]
            self.assertEqual(discovered["id"], slices[0]["decision_id"])
            self.assertTrue(slices[0]["implementation_ready"])
            self.assertTrue(slices[0]["evidence_backed"])
            self.assertEqual("codebase", slices[0]["evidence_source"])
            self.assertEqual("Implement Password reset before launch.", slices[0]["next_step"])
            plan = generate_plan(ai_dir, [session_id])
            self.assertEqual("action-plan", plan["status"])
            self.assertEqual(discovered["id"], plan["action_plan"]["implementation_ready_slices"][0]["decision_id"])
            self.assertEqual(discovered["id"], plan["action_plan"]["action_slices"][0]["decision_id"])
            plan_body = Path(plan["export_path"]).read_text(encoding="utf-8")
            self.assertIn("Implementation-Ready Slices", plan_body)
            self.assertIn("via codebase", plan_body)
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_extracts_multiple_constraints_and_decisions(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Extract multiple constraints and follow-up decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Retention decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-021",
                    "title": "Audit retention",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "ops",
                    "resolvable_by": "human",
                    "question": "How long should audit logs be retained?",
                    "context": "Retention affects compliance scope.",
                    "options": [{"summary": "Start with 30 days."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=tmp)
            reply = handle_reply(
                ai_dir,
                session_id,
                (
                    "Use 90 days, but only for enterprise tenants, and it must stay in the US, "
                    "and we also need S3 export before launch, and we need retention to be configurable later."
                ),
                repo_root=tmp,
            )
            self.assertEqual("accepted", reply["status"])
            self.assertEqual("Use 90 days", reply["decision"]["accepted_answer"]["summary"])
            self.assertEqual(
                ["only for enterprise tenants", "it must stay in the US"],
                reply["captured_constraints"],
            )
            self.assertEqual(2, len(reply["discovered_decisions"]))
            by_title = {item["title"]: item for item in reply["discovered_decisions"]}
            self.assertEqual("technical", by_title["S3 export before launch"]["domain"])
            self.assertEqual("dependency", by_title["S3 export before launch"]["kind"])
            self.assertEqual("codebase", by_title["S3 export before launch"]["resolvable_by"])
            self.assertEqual("reversible", by_title["S3 export before launch"]["reversibility"])
            self.assertEqual(
                "What implementation do we need for S3 export before launch?",
                by_title["S3 export before launch"]["question"],
            )
            self.assertEqual("ops", by_title["Retention to be configurable later"]["domain"])
            self.assertEqual("choice", by_title["Retention to be configurable later"]["kind"])
            self.assertEqual("human", by_title["Retention to be configurable later"]["resolvable_by"])
            self.assertEqual("reversible", by_title["Retention to be configurable later"]["reversibility"])
            self.assertEqual(
                "How should we handle retention to be configurable later?",
                by_title["Retention to be configurable later"]["question"],
            )
            priorities = {(item["priority"], item["frontier"]) for item in reply["discovered_decisions"]}
            self.assertIn(("P0", "now"), priorities)
            self.assertIn(("P2", "later"), priorities)
            self.assertEqual("question", reply["next_turn"]["status"])
            self.assertEqual([], validate_runtime(ai_dir))

    def test_handle_reply_discovers_legal_constraint_from_follow_up_clause(self) -> None:
        with TemporaryDirectory() as tmp:
            ai_dir = str(Path(tmp) / ".ai" / "decide-me")
            bootstrap_runtime(
                ai_dir,
                project_name="Demo",
                objective="Infer legal follow-up decisions",
                current_milestone="MVP",
            )
            session_id = create_session(ai_dir, context="Auth decision")["session"]["id"]
            discover_decision(
                ai_dir,
                session_id,
                {
                    "id": "D-022",
                    "title": "Authentication mode",
                    "priority": "P0",
                    "frontier": "now",
                    "domain": "technical",
                    "resolvable_by": "human",
                    "question": "Should the MVP use magic links?",
                    "context": "Choose the initial authentication mode.",
                    "options": [{"summary": "Use magic links for the MVP."}],
                },
            )

            advance_session(ai_dir, session_id, repo_root=tmp)
            reply = handle_reply(
                ai_dir,
                session_id,
                "Use magic links, and we also need EU data residency before launch.",
                repo_root=tmp,
            )
            self.assertEqual("accepted", reply["status"])
            self.assertEqual(1, len(reply["discovered_decisions"]))
            discovered = reply["discovered_decisions"][0]
            self.assertEqual("legal", discovered["domain"])
            self.assertEqual("constraint", discovered["kind"])
            self.assertEqual("P0", discovered["priority"])
            self.assertEqual("now", discovered["frontier"])
            self.assertEqual("external", discovered["resolvable_by"])
            self.assertEqual("hard-to-reverse", discovered["reversibility"])
            self.assertEqual(
                "What external requirement should apply to EU data residency before launch?",
                discovered["question"],
            )
            self.assertEqual([], validate_runtime(ai_dir))


if __name__ == "__main__":
    unittest.main()
